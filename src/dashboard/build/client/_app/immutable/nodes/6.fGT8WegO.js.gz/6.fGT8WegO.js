import"../chunks/Bzak7iHL.js";import"../chunks/69_IOA4Y.js";import{E as o}from"../chunks/BJjG3ugc.js";function p(r){o(r,{boxStyles:"bg-red-400/40 dark:bg-red-500/20"})}export{p as component};
