import{_ as t}from"./DXUvcUDv.js";const o=t({questions:[]}),a=t({tags:[]});export{o as q,a as t};
