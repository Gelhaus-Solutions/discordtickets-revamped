import{_ as t}from"./BP9m31RR.js";const o=t({questions:[]}),a=t({tags:[]});export{o as q,a as t};
